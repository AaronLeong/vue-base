<template>
  <div>
    Hello World! This content is restricted.
  </div>
</template>

<script>
export default {

}
</script>
